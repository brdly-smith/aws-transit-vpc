from pkg_resources import get_distribution

__version__ = get_distribution('transit-vpc-push-cisco-config').version
__release_date__ = "Aug-2017"
